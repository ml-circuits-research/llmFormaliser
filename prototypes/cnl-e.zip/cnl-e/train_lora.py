#!/usr/bin/env python3
"""Fine-tune a small causal LM to translate text into CNL-E.

LoRA by default; --qlora loads the base model in 4-bit; --full trains all weights
(sensible for students of about 1.7B parameters or less).

The loss is computed on the CNL answer only, never on the prompt.

Examples:
    python3 train_lora.py --model Qwen/Qwen3-4B-Instruct-2507 \
        --train data/train.jsonl --eval data/dev.jsonl --out runs/qwen3-4b-cnl

    python3 train_lora.py --smoke-test        # tiny random model, CPU, about a minute:
                                              # checks the pipeline, not the quality

Needs: pip install -r requirements.txt   (and bitsandbytes for --qlora)
"""
import argparse
import dataclasses
import math
import random

import torch
from torch.utils.data import Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments

from common import HERE, read_jsonl, user_message


# --------------------------------------------------------------------------- data
class PairDataset(Dataset):
    """Each item: prompt tokens (label -100) followed by answer tokens (label = token)."""

    def __init__(self, rows, tok, max_len, field="cnl"):
        self.items, self.skipped = [], 0
        for row in rows:
            row = {**row, "cnl": row[field]}
            user = [{"role": "user", "content": user_message(row["source"])}]
            prefix = tok.apply_chat_template(user, tokenize=False, add_generation_prompt=True)
            full = tok.apply_chat_template(user + [{"role": "assistant", "content": row["cnl"]}],
                                           tokenize=False)
            if full.startswith(prefix):
                answer = full[len(prefix):]          # the answer exactly as the template ends it
            else:                                    # template rewrites the prefix: end it ourselves
                answer = row["cnl"] + (tok.eos_token or "")
            p = tok(prefix, add_special_tokens=False)["input_ids"]
            a = tok(answer, add_special_tokens=False)["input_ids"]
            if len(p) + len(a) > max_len:
                self.skipped += 1                    # never truncate a target: a cut CNL is invalid
                continue
            self.items.append({"input_ids": p + a, "labels": [-100] * len(p) + a})

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        return self.items[i]


def make_collator(pad_id):
    def collate(batch):
        width = max(len(b["input_ids"]) for b in batch)
        ids = torch.full((len(batch), width), pad_id, dtype=torch.long)
        labels = torch.full((len(batch), width), -100, dtype=torch.long)
        mask = torch.zeros((len(batch), width), dtype=torch.long)
        for i, b in enumerate(batch):
            n = len(b["input_ids"])
            ids[i, :n] = torch.tensor(b["input_ids"])
            labels[i, :n] = torch.tensor(b["labels"])
            mask[i, :n] = 1
        return {"input_ids": ids, "attention_mask": mask, "labels": labels}
    return collate


# --------------------------------------------------------------------------- smoke test
CHATML = ("{% for m in messages %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}"
          "{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}")


def tiny_model_and_tokenizer(rows):
    """A random 2-layer Llama-shaped model and a tokenizer trained on the seed pairs. No downloads."""
    from tokenizers import Tokenizer, models, pre_tokenizers, decoders, trainers
    from transformers import LlamaConfig, LlamaForCausalLM, PreTrainedTokenizerFast

    special = ["<pad>", "<|im_start|>", "<|im_end|>"]
    t = Tokenizer(models.BPE())
    t.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    t.decoder = decoders.ByteLevel()
    corpus = [user_message(r["source"]) + "\n" + r["cnl"] + "\nuser assistant" for r in rows]
    t.train_from_iterator(corpus, trainers.BpeTrainer(
        vocab_size=600, special_tokens=special, initial_alphabet=pre_tokenizers.ByteLevel.alphabet()))
    tok = PreTrainedTokenizerFast(tokenizer_object=t, pad_token="<pad>", eos_token="<|im_end|>")
    tok.chat_template = CHATML
    cfg = LlamaConfig(vocab_size=len(tok), hidden_size=64, intermediate_size=128, num_hidden_layers=2,
                      num_attention_heads=4, num_key_value_heads=4, max_position_embeddings=512,
                      pad_token_id=tok.pad_token_id, eos_token_id=tok.eos_token_id, bos_token_id=None)
    return LlamaForCausalLM(cfg), tok


# --------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", default="Qwen/Qwen3-4B-Instruct-2507")
    ap.add_argument("--train", default="data/train.jsonl")
    ap.add_argument("--eval", default=None, help="dev set; if omitted, 2%% of train is held out")
    ap.add_argument("--out", default="runs/cnl-lora")
    ap.add_argument("--epochs", type=float, default=3)
    ap.add_argument("--lr", type=float, default=None, help="default: 2e-4 LoRA, 2e-5 full")
    ap.add_argument("--rank", type=int, default=32)
    ap.add_argument("--alpha", type=int, default=64)
    ap.add_argument("--dropout", type=float, default=0.05)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--grad-accum", type=int, default=4)
    ap.add_argument("--max-len", type=int, default=768)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--qlora", action="store_true", help="load the base model in 4-bit (needs bitsandbytes)")
    ap.add_argument("--full", action="store_true", help="train all weights instead of LoRA")
    ap.add_argument("--merge", action="store_true", help="also save merged full weights in <out>/merged")
    ap.add_argument("--field", default="cnl",
                    help="which field of the JSONL rows is the target: cnl (bracket form) or kv (line form)")
    ap.add_argument("--smoke-test", action="store_true")
    args = ap.parse_args()
    random.seed(args.seed)
    torch.manual_seed(args.seed)

    cuda = torch.cuda.is_available()
    if args.smoke_test:
        rows = read_jsonl(HERE / "data" / "seed.jsonl")
        model, tok = tiny_model_and_tokenizer(rows)
        train_rows, eval_rows = rows, rows[:8]
        args.out, args.epochs, args.batch, args.grad_accum = "runs/smoke", 2, 8, 1
    else:
        tok = AutoTokenizer.from_pretrained(args.model)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        kwargs = {"torch_dtype": torch.bfloat16 if cuda else torch.float32}
        if cuda:
            kwargs["device_map"] = "auto"
        if args.qlora:
            from transformers import BitsAndBytesConfig
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.bfloat16)
        model = AutoModelForCausalLM.from_pretrained(args.model, **kwargs)
        train_rows = read_jsonl(args.train)
        if args.eval:
            eval_rows = read_jsonl(args.eval)
        else:
            random.shuffle(train_rows)
            cut = max(1, len(train_rows) // 50)
            eval_rows, train_rows = train_rows[:cut], train_rows[cut:]

    train_ds = PairDataset(train_rows, tok, args.max_len, args.field)
    eval_ds = PairDataset(eval_rows, tok, args.max_len, args.field)
    print(f"train {len(train_ds)} pairs (skipped {train_ds.skipped} longer than --max-len), "
          f"eval {len(eval_ds)}")

    if not args.full:
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
        if args.qlora:
            model = prepare_model_for_kbit_training(model)
        model = get_peft_model(model, LoraConfig(
            r=args.rank, lora_alpha=args.alpha, lora_dropout=args.dropout, bias="none",
            target_modules="all-linear", task_type="CAUSAL_LM"))
        model.print_trainable_parameters()

    lr = args.lr or (2e-5 if args.full else 2e-4)
    steps = math.ceil(len(train_ds) / (args.batch * args.grad_accum)) * args.epochs
    wanted = dict(
        output_dir=args.out, num_train_epochs=args.epochs, learning_rate=lr,
        per_device_train_batch_size=args.batch, per_device_eval_batch_size=args.batch,
        gradient_accumulation_steps=args.grad_accum, lr_scheduler_type="cosine",
        warmup_steps=max(1, int(0.05 * steps)), weight_decay=0.0, max_grad_norm=1.0,
        logging_steps=max(1, int(steps // 50)), eval_strategy="epoch", save_strategy="epoch",
        save_total_limit=2, bf16=cuda, report_to="none", seed=args.seed, use_cpu=not cuda)
    known = {f.name for f in dataclasses.fields(TrainingArguments)}      # names differ across versions
    dropped = sorted(set(wanted) - known)
    if dropped:
        print("note: this transformers version ignores", dropped)
    targs = TrainingArguments(**{k: v for k, v in wanted.items() if k in known})
    trainer = Trainer(model=model, args=targs, train_dataset=train_ds, eval_dataset=eval_ds,
                      data_collator=make_collator(tok.pad_token_id))
    before = trainer.evaluate()["eval_loss"]
    trainer.train()
    after = trainer.evaluate()["eval_loss"]
    print(f"eval loss: {before:.3f} -> {after:.3f}")

    model.save_pretrained(args.out)
    tok.save_pretrained(args.out)
    if args.merge and not args.full:
        merged = model.merge_and_unload()
        merged.save_pretrained(f"{args.out}/merged")
        tok.save_pretrained(f"{args.out}/merged")
    if args.smoke_test:
        assert after < before, "loss did not go down"
        print("SMOKE TEST PASSED: data, label masking, LoRA, training loop and saving all work")


if __name__ == "__main__":
    main()
