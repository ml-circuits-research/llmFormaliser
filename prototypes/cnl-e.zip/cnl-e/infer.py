#!/usr/bin/env python3
"""Translate text to CNL-E with a fine-tuned model, and never return an unchecked answer.

Modes:
    plain        greedy decoding, then validate
    constrained  every token is masked by the grammar (cnl_llg.lark, via llguidance)
    fallback     plain first; only if the answer is invalid, decode again constrained   [default]

Input: a .txt file (one text per line) or a .jsonl file with a "source" field.
Output: JSONL with source, cnl, valid, errors, mode.

Examples:
    python3 infer.py --model runs/qwen3-4b-cnl --input texts.txt --out pred.jsonl
    python3 infer.py --smoke-test         # random tiny model: checks the decoding loop only
    python3 infer.py --model Qwen/Qwen3-4B-Instruct-2507 --check-grammar
                                          # does the grammar mask fit this model's tokenizer?
"""
import argparse
import time

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, LogitsProcessor, LogitsProcessorList

import canon
import cnl_check
from common import HERE, read_jsonl, user_message, write_jsonl


class GrammarMask(LogitsProcessor):
    """Allows only tokens that keep the output inside the CNL-E grammar (batch size 1)."""

    def __init__(self, ll_tokenizer, grammar, prompt_len):
        import llguidance
        self.matcher = llguidance.LLMatcher(ll_tokenizer, grammar, log_level=0)
        self.prompt_len, self.seen = prompt_len, 0

    def __call__(self, input_ids, scores):
        new = input_ids[0, self.prompt_len + self.seen:].tolist()
        if new:
            self.matcher.consume_tokens(new)
            self.seen += len(new)
        bits = np.unpackbits(np.frombuffer(self.matcher.compute_bitmask(), dtype=np.uint8),
                             bitorder="little")[: scores.shape[-1]]
        allowed = torch.from_numpy(bits.astype(bool)).to(scores.device)
        if not allowed.any():                      # grammar finished or dead end: force the end token
            return scores
        return scores.masked_fill(~allowed.unsqueeze(0), float("-inf"))


class Translator:
    def __init__(self, model, tok):
        self.model, self.tok = model.eval(), tok
        self.eos = [t for t in {tok.eos_token_id, tok.convert_tokens_to_ids("<|im_end|>"),
                                tok.convert_tokens_to_ids("<end_of_turn>")}
                    if isinstance(t, int) and t >= 0 and t != tok.unk_token_id]
        self._ll = None
        self.new_tokens = 0

    def _grammar(self):
        if self._ll is None:
            import llguidance
            import llguidance.hf
            self._ll = (llguidance.hf.from_tokenizer(self.tok, eos_token=self.eos),
                        llguidance.grammar_from("lark", (HERE / "cnl_llg.lark").read_text()))
        return self._ll

    @torch.no_grad()
    def _generate(self, source, constrained, max_new_tokens):
        prompt = self.tok.apply_chat_template([{"role": "user", "content": user_message(source)}],
                                              tokenize=False, add_generation_prompt=True)
        ids = self.tok(prompt, add_special_tokens=False, return_tensors="pt")["input_ids"].to(self.model.device)
        procs = LogitsProcessorList()
        if constrained:
            ll_tok, grammar = self._grammar()
            procs.append(GrammarMask(ll_tok, grammar, ids.shape[1]))
        budget = max_new_tokens or min(768, 4 * len(self.tok(source)["input_ids"]) + 48)
        out = self.model.generate(ids, attention_mask=torch.ones_like(ids), max_new_tokens=budget,
                                  do_sample=False, logits_processor=procs, eos_token_id=self.eos,
                                  pad_token_id=self.tok.pad_token_id)
        new = out[0, ids.shape[1]:]
        self.new_tokens += len(new)
        return self.tok.decode(new, skip_special_tokens=True).strip()

    def translate(self, source, mode="fallback", max_new_tokens=None):
        first = "constrained" if mode == "constrained" else "plain"
        cnl = canon.canonicalize(self._generate(source, first == "constrained", max_new_tokens))
        errors, used = cnl_check.check(cnl), first
        if errors and mode == "fallback":
            cnl2 = canon.canonicalize(self._generate(source, True, max_new_tokens))
            errors2 = cnl_check.check(cnl2)
            if not errors2 or not cnl:
                cnl, errors, used = cnl2, errors2, "constrained"
        return {"source": source, "cnl": cnl, "valid": not errors, "errors": errors, "mode": used}


def check_grammar(tr, rows):
    """Every reference CNL, tokenized by the model's own tokenizer, must pass the mask
    token by token and end in an accepting state. This is what makes constrained decoding
    safe: the grammar never blocks a correct answer. Run it once per new base model."""
    import llguidance
    ll_tok, grammar = tr._grammar()
    for row in rows:
        m = llguidance.LLMatcher(ll_tok, grammar, log_level=0)
        for t in tr.tok(row["cnl"], add_special_tokens=False)["input_ids"]:
            bits = np.unpackbits(np.frombuffer(m.compute_bitmask(), dtype=np.uint8), bitorder="little")
            assert bits[t], f"mask blocks token {tr.tok.decode([t])!r} in:\n{row['cnl']}"
            m.consume_token(t)
        assert m.is_accepting(), f"reference CNL not accepted:\n{row['cnl']}"
    print(f"grammar mask accepts all {len(rows)} reference CNLs token by token")


def smoke_test():
    import llguidance
    from train_lora import tiny_model_and_tokenizer
    torch.manual_seed(0)
    rows = read_jsonl(HERE / "data" / "seed.jsonl")
    model, tok = tiny_model_and_tokenizer(rows)
    tr = Translator(model, tok)
    ll_tok, grammar = tr._grammar()
    check_grammar(tr, rows)

    # 2. A random model is not valid by itself, and under the mask it never leaves the grammar.
    plain = tr.translate(rows[0]["source"], mode="plain", max_new_tokens=40)
    assert not plain["valid"], "a random model should not produce valid CNL by itself"
    for row in rows[:6]:
        text = tr._generate(row["source"], constrained=True, max_new_tokens=60)
        m = llguidance.LLMatcher(ll_tok, grammar, log_level=0)
        for t in tok(text, add_special_tokens=False)["input_ids"]:
            assert m.consume_token(t) and not m.is_error(), f"left the grammar: {text!r}"
    print("random model: invalid when free, stays inside the grammar when masked")
    print("SMOKE TEST PASSED: generation, grammar mask, canonicalization and validation all work")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", help="merged model directory, or a LoRA adapter directory")
    ap.add_argument("--input")
    ap.add_argument("--out", default="pred.jsonl")
    ap.add_argument("--mode", choices=["plain", "constrained", "fallback"], default="fallback")
    ap.add_argument("--smoke-test", action="store_true")
    ap.add_argument("--check-grammar", action="store_true",
                    help="only load the tokenizer of --model and replay data/seed.jsonl through the mask")
    args = ap.parse_args()
    if args.smoke_test:
        return smoke_test()
    if args.check_grammar:
        tr = Translator.__new__(Translator)
        tr.tok, tr._ll = AutoTokenizer.from_pretrained(args.model), None
        tr.eos = [tr.tok.eos_token_id]
        return check_grammar(tr, read_jsonl(HERE / "data" / "seed.jsonl"))

    cuda = torch.cuda.is_available()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16 if cuda else torch.float32,
        **({"device_map": "auto"} if cuda else {}))
    tr = Translator(model, tok)
    if args.input.endswith(".jsonl"):
        sources = [r["source"] for r in read_jsonl(args.input)]
    else:
        sources = [ln.strip() for ln in open(args.input, encoding="utf-8") if ln.strip()]

    start, results = time.time(), []
    for src in sources:
        results.append(tr.translate(src, mode=args.mode))
    secs = time.time() - start
    write_jsonl(args.out, results)
    valid = sum(r["valid"] for r in results)
    retried = sum(r["mode"] == "constrained" for r in results) if args.mode == "fallback" else 0
    print(f"{len(results)} texts in {secs:.1f}s ({len(results) / secs:.2f} texts/s, "
          f"{tr.new_tokens / secs:.0f} generated tokens/s)")
    print(f"valid: {valid}/{len(results)}" + (f" | needed the grammar: {retried}" if retried else ""))


if __name__ == "__main__":
    main()
