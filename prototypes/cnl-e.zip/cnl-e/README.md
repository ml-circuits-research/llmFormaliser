# CNL-E: limbaj controlat pe evenimente, cu tot ce trebuie pentru antrenare

Din text natural în CNL regulat, fără LLM mare la rulare.

```
The report that John said he would send to Mary wasn't finished.

E1 fact John say E2; PAST
E2 claim John send report-1; to=Mary; FUTURE
E3 fact _ not finish report-1; PAST
```

## Ce citești întâi

| Fișier | Conținut |
| --- | --- |
| `FORMAT.md` | scrierea finală, pe linii, cu cuvinte-cheie; promptul pentru un LLM și proba cu Haiku |
| `SPEC.md` | limbajul: reguli, limite, decizii deschise (în scrierea cu paranteze) |
| `TRAINING.md` | ce model, ce tehnică, cum faci datele, cum antrenezi, cum măsori |
| `JSON.md` | același limbaj ca JSON; util doar dacă API-ul modelului impune o schemă |

## Pornire rapidă

```
pip install lark
python3 run_tests.py --core        # gramatică + validator: câteva secunde

pip install -r requirements.txt
python3 -m spacy download en_core_web_sm
python3 run_tests.py               # toate verificările, fără GPU și fără descărcări de modele
```

## Fișiere

| Fișier | Rol |
| --- | --- |
| `cnl.lark` | gramatica de referință (Lark, LALR) |
| `cnl_llg.lark` | aceeași gramatică pentru decodare constrânsă (llguidance) |
| `cnl_check.py` | validator: gramatică + reguli de coerență |
| `canon.py` | numerotare canonică: un sens, o scriere |
| `lemma_check.py` | cuvinte pierdute sau inventate și negații, față de textul sursă |
| `data/examples.txt` | 64 de perechi corecte, pe categorii |
| `data/invalid.txt` | 23 de texte care trebuie respinse |
| `data/seed.jsonl` | exemplele în format JSONL (generat de `prepare_data.py`) |
| `prompts/rules_en.md` | regulile, compact, în engleză, pentru modelul profesor |
| `prompts/teacher_prompt.txt` | promptul complet pentru profesor (generat de `build_teacher_prompt.py`) |
| `prompts/sentence_generation.md` | categorii și ponderi pentru propozițiile sursă; perechi minimale |
| `filter_synthetic.py` | filtrează perechile venite de la profesor |
| `train_lora.py` | fine-tuning LoRA, QLoRA sau complet |
| `infer.py` | traducere cu validare și, la nevoie, mască de gramatică |
| `evaluate.py` | valid, exact, F1 pe sloturi, față de un set gold |
| `cnl_kv.py` | scrierea pe linii: parser, verificator, scriere canonică, scor |
| `prompts/kv_rules_en.md`, `prompts/kv_prompt.txt` | regulile și promptul final (generat de `build_kv_prompt.py`) |
| `trials/haiku_lines/` | datele probei cu promptul final: propoziții, referințe, două rulări, reîncercări |
| `cnl_json.py` | forma JSON și documentul comun: convertor, verificator, scor |
| `cnl_schema.json` | schema JSON, pentru API-uri care impun scheme |
| `prompts/json_rules_en.md`, `prompts/json_prompt.txt` | regulile și promptul complet pentru ieșire JSON (generat de `build_json_prompt.py`) |
| `trials/haiku_json/` | datele probei cu Haiku: propoziții, referințe, două rulări |
| `test_llg.py` | verifică dacă cele două gramatici acceptă aceleași texte |
| `run_tests.py` | rulează toate verificările |

## Ce este testat și ce nu

Testat aici, pe CPU: gramatica și validatorul pe 64 + 23 de texte; acordul dintre cele două
gramatici pe aceleași 87 de texte; filtrul de date; scriptul de evaluare; bucla de antrenare și
masca de gramatică pe un model aleator minuscul.

Testat cu un model real: promptul final, pe Haiku, de două ori pe 51 de propoziții (`FORMAT.md`),
și înainte promptul JSON, de două ori pe 48 de propoziții (`JSON.md`).

Netestat: antrenarea și inferența pe un model real, pe GPU; serverele llama.cpp, SGLang și vLLM.
Nu există încă niciun model antrenat și nicio măsurătoare de viteză.
