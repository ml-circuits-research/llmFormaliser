# Prompt for generating SOURCE sentences (not CNL)

Real text from your own domain is the best source and should be at least half of the data.
Use this prompt only to fill the phenomena that real text rarely contains.

```
Write {N} English sentences or 2-3 sentence paragraphs for the category below.
Vary topic (office, software, travel, family, science, commerce), length (5 to 40 words),
names, tense and register. One item per line, no numbering, no commentary.

Category: {CATEGORY}
```

## Categories and suggested share of the training set

These shares are a starting point, not a measured optimum. Shift them toward whatever
the gold-set error analysis shows the model getting wrong.

| Share | Category to paste into the prompt |
| --- | --- |
| 20% | plain statements with adjectives, time, place and manner complements |
| 12% | reported speech, belief, wanting, promising, with the subordinate clause explicit |
| 10% | negation in different positions: main verb, subordinate verb, modal, "never", "nobody", "no + noun" |
| 8% | relative clauses, restrictive and non-restrictive, including long-distance ones ("the report that John said he would send") |
| 8% | quantifiers (every, most, no, at least three, not every) and comparatives |
| 8% | direct questions: yes/no, who, what, when, where, why, how, which, how many; and embedded questions |
| 8% | orders, polite requests, prohibitions, and data queries ("show me all X that ...", "list ...") |
| 6% | exclamations, interjections, greetings, thanks, apologies, wishes, strong emotion |
| 6% | noisy spoken text: fillers, false starts, repetitions, hedging |
| 5% | mathematics said in words or symbols: equations, inequalities, definitions, units, percentages |
| 5% | paragraphs of 2-5 sentences where pronouns refer back across sentences |
| 4% | conditionals, causes, concessions, purposes (if, because, although, so that, unless) |

## Minimal pairs (at least 10% of the whole set)

Ask for these explicitly; they are what teaches structure instead of word overlap.

```
Write {N} PAIRS of sentences. The two sentences of a pair use almost the same words
but differ in exactly one of:
  (a) what the negation applies to        (did not promise to leave / promised not to leave)
  (b) what a prepositional phrase modifies (saw the man with the telescope: instrument vs. owner;
      make the reading unambiguous by context)
  (c) who a pronoun refers to             (make the referent unambiguous by gender or plausibility)
  (d) whether a modal or its verb is negated (must not open / need not open)
  (e) which noun an adjective modifies    (the old manager's car / the manager's old car)
Output the two sentences of a pair on consecutive lines, then a blank line.
```
