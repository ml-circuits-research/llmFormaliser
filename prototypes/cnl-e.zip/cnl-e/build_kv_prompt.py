#!/usr/bin/env python3
"""Build prompts/kv_prompt.txt: the final system prompt for the CNL-E line form.

    python3 build_kv_prompt.py

Send the prompt as the system message and the text to convert as the user message, one text
per call. Check every answer with cnl_kv.check(); if it returns errors, send them back and
ask for the corrected lines.
"""
import cnl_json
import cnl_kv
from common import HERE, read_jsonl


def main():
    pairs = read_jsonl(HERE / "data" / "seed.jsonl")
    rules = (HERE / "prompts" / "kv_rules_en.md").read_text(encoding="utf-8")
    examples = [f"Text: {p['source']}\n{cnl_kv.dumps(cnl_json.to_json(p['cnl']))}" for p in pairs]
    prompt = rules + "\n## Examples\n\n" + "\n\n".join(examples) + "\n"
    (HERE / "prompts" / "kv_prompt.txt").write_text(prompt, encoding="utf-8")
    print(f"wrote prompts/kv_prompt.txt: {len(pairs)} examples, {len(prompt)} characters")


if __name__ == "__main__":
    main()
