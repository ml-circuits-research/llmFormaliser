"""Shared pieces: the instruction given to the model, and JSONL helpers."""
import json
from pathlib import Path

HERE = Path(__file__).parent

# Kept deliberately short: the model learns CNL-E from the pairs, not from the prompt,
# and every prompt token is paid again on each call.
INSTRUCTION = "Rewrite as CNL-E:\n"


def user_message(source):
    return INSTRUCTION + source.strip()


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
