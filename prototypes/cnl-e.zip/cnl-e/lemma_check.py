#!/usr/bin/env python3
"""Lemma-coverage check between a source sentence and its CNL-E rendering.

It catches what the grammar cannot: a content word that disappeared, a word that
was invented, a lost or added negation. It does NOT catch wrong attachment or
wrong scope when all the words are present.

Use it as a FILTER on synthetic training data, not as proof of correctness.

Usage:
    python3 lemma_check.py --test                 # run over data/examples.txt
    python3 lemma_check.py "source text" file.cnl

Needs: pip install spacy lark  +  the en_core_web_sm model.
"""
import re
import sys
from pathlib import Path
from lark import Token, Tree
import cnl_check

_NLP = None

# Source words that legitimately vanish or turn into flags / symbols / structure.
DROPPED = {
    # fillers and discourse markers
    "well", "um", "uh", "erm", "like", "basically", "actually", "honestly", "so", "just",
    "know", "mean", "oh", "then",
    # politeness and emphasis -> [POLITE] / [EMPH]
    "please", "could", "would", "can", "let",
    # determiners / pro-forms resolved by ids
    "one", "another", "other", "what", "which", "who", "whose", "whether", "how", "why", "when", "where",
    "many", "much",
    # comparison words that become < > <= >= ~
    "more", "less", "than", "least", "most", "about", "great", "small", "equal", "equals",
    # tense / aspect carriers
    "be", "have", "do", "will", "go",
}
# CNL words that may appear without a source counterpart.
INTRODUCED = {"be", "time", "place", "manner", "mode", "degree", "cause", "purpose", "freq", "duration",
              "wish", "to", "of", "you", "we", "i"}
NUMBER_WORDS = {"zero": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
                "seven": "7", "eight": "8", "nine": "9", "ten": "10", "eleven": "11", "twelve": "12",
                "twenty": "20", "thirty": "30", "forty": "40", "fifty": "50", "hundred": "100",
                "thousand": "1000"}
NEG_SOURCE = {"not", "n't", "no", "never", "nobody", "nothing", "none", "neither", "nor", "without"}
NEG_CNL = {"not", "no", "never", "nobody", "nothing", "none", "neither", "without", "not_every",
           "not_all", "not_many"}
CONTENT_POS = {"NOUN", "PROPN", "VERB", "ADJ", "ADV", "NUM"}


def nlp():
    global _NLP
    if _NLP is None:
        import spacy
        _NLP = spacy.load("en_core_web_sm", disable=["ner"])
    return _NLP


def cnl_words(cnl):
    """Return (content words, label words, negation count, has_formula) of a CNL text."""
    tree = cnl_check.PARSER.parse(cnl.strip() + "\n")
    words, labels, negs, formula = set(), set(), 0, False

    def add(text):
        for part in re.split(r"[_\s/]+", text.lower()):
            part = part.strip("'.\"")
            if part:
                words.add(part)

    def walk(node, skip_first_word=False):
        nonlocal negs, formula
        first = True
        for ch in node.children:
            if isinstance(ch, Tree):
                if ch.data == "formula":
                    formula = True
                walk(ch, skip_first_word=ch.data in ("tag", "npmod"))
                continue
            t, v = ch.type, str(ch)
            if t == "WORD" and skip_first_word and first:
                labels.add(v)
                first = False
                if v in NEG_CNL:
                    negs += 1
                continue
            if t == "NOT" or (t in ("WORD", "QUANT") and v in NEG_CNL):
                negs += 1
            if t == "NOUN":
                lemma = re.sub(r"-[0-9]+\+?$", "", v)
                if lemma in NEG_CNL:
                    negs += 1
                add(lemma)
            elif t == "NAME":
                add(re.sub(r"-[0-9]+$", "", v))
            elif t in ("WORD", "QUANT", "FOCUS", "PRON", "MNAME"):
                add(v)
            elif t in ("NUMBER", "QUANTITY"):
                add(v.lstrip("-").replace("%", ""))
            elif t in ("DATE", "TIME"):
                words.add(v)
                for part in re.split(r"[-:]", v):
                    add(part)
            elif t == "STRING":
                for w in re.findall(r"[A-Za-z0-9']+", v):
                    add(w)
                    if w.lower() in NEG_CNL:
                        negs += 1

    walk(tree)
    return words, labels, negs, formula


def same_stem(a, b):
    """smoke ~ smoking, tall ~ taller: a shared prefix of at least 4 letters, endings differ by <= 3."""
    n = 0
    while n < min(len(a), len(b)) and a[n] == b[n]:
        n += 1
    return n >= 4 and max(len(a), len(b)) - n <= 3


def doc_words(doc):
    """Same as cnl_words, for a document dict (the JSON form / the parsed line form)."""
    words, labels, formula = set(), set(), False
    negs = 0

    def add(text):
        for part in re.split(r"[_\s/]+", text.lower()):
            part = part.strip("'.\"")
            if part:
                words.add(part)

    def value(v):
        nonlocal negs, formula
        if isinstance(v, dict):
            if "focus" in v:
                add(v["focus"])
            for item in v["items"]:
                value(item)
            return
        if v.startswith("$"):
            formula = True
            for w in re.findall(r"[A-Za-z][A-Za-z0-9_]*", v):
                add(w)
        elif v.startswith('"'):
            for w in re.findall(r"[A-Za-z0-9']+", v):
                add(w)
                negs += w.lower() in NEG_CNL
        elif re.fullmatch(r"[a-z][a-z0-9_']*-[0-9]+", v):
            lemma = v.rsplit("-", 1)[0]
            negs += lemma in NEG_CNL
            add(lemma)
        elif re.fullmatch(r"[0-9]{4}-[0-9]{2}(-[0-9]{2})?|[0-9]{1,2}:[0-9]{2}", v):
            words.add(v)
            for part in re.split(r"[-:]", v):
                add(part)
        elif re.fullmatch(r"E[0-9]+|_|\?[a-z_]+", v):
            pass
        else:
            for w in v.split():
                negs += w in NEG_CNL
                add(re.sub(r"^(<=|>=|<|>|~)", "", w).lstrip("-").replace("%", ""))

    def tags(lst):
        nonlocal negs
        for t in lst:
            labels.add(t["label"])
            negs += (t["label"] in NEG_CNL) + bool(t.get("not"))
            value(t["value"])

    for e in doc.get("entities", []):
        if "quant" in e:
            negs += e["quant"] in NEG_CNL
            add(re.sub(r"^(<=|>=|<|>|~|\?)", "", e["quant"]))
        for a in e.get("adj", []):
            add(a)
        tags(e.get("mods", []))
    for ev in doc["events"]:
        negs += bool(ev.get("not")) + (ev.get("logic") == "not")
        if "verb" in ev:
            add(ev["verb"])
        if "formula" in ev:
            formula = True
        for k in ("who", "what"):
            if k in ev:
                value(ev[k])
        tags(ev.get("tags", []))
    return words, labels, negs, formula


def compare_doc(source, doc):
    """compare() for a document dict."""
    return _compare(source, *doc_words(doc))


def compare(source, cnl):
    """Return dict(missing, extra, neg_source, neg_cnl, ok)."""
    return _compare(source, *cnl_words(cnl))


def _compare(source, words, labels, neg_cnl, has_formula):
    source = re.sub(r"\bif only\b", "", source, flags=re.I)        # optative -> [mode: wish]
    doc = nlp()(source)
    src_all, src_content, neg_src = set(), [], 0
    for tok in doc:
        low, lem = tok.text.lower().strip(".,!?;:"), tok.lemma_.lower().strip(".,!?;:")
        if low in NEG_SOURCE or lem in NEG_SOURCE:
            neg_src += 1
        forms = {low, lem, NUMBER_WORDS.get(low, low), low.rstrip("%")}
        src_all |= forms
        if tok.pos_ in CONTENT_POS and not (forms & DROPPED) and re.search(r"[a-z0-9]", low):
            src_content.append(forms)
    cnl_all = words | labels
    missing = sorted({min(f, key=len) for f in src_content
                      if not (f & cnl_all) and not any(same_stem(a, b) for a in f for b in cnl_all)})
    extra = sorted(w for w in words
                   if w not in src_all and w not in INTRODUCED and not re.search(r"[0-9]", w)
                   and not any(same_stem(w, s) for s in src_all))
    if has_formula:            # spoken maths is rewritten as symbols: only names can be compared
        names = {t.text.lower() for t in doc if t.pos_ == "PROPN" and t.text.isalpha() and len(t.text) > 1}
        missing = [m for m in missing if m in names]
        extra = []
    ok = not missing and not extra and neg_src == neg_cnl
    return {"missing": missing, "extra": extra, "neg_source": neg_src, "neg_cnl": neg_cnl, "ok": ok}


def clean0(note):
    note = re.sub(r"^[A-F][0-9]+[ab]?\.\s*", "", note)
    return re.sub(r"\s{2,}\(.*\)\s*$", "", note)


def run_tests():
    blocks = cnl_check.read_blocks(Path(__file__).parent / "data" / "examples.txt")
    flagged = 0
    for note, cnl in blocks:
        source = re.sub(r"^[A-F][0-9]+[ab]?\.\s*", "", note)          # drop the "A1." prefix
        source = re.sub(r"\s{2,}\(.*\)\s*$", "", source)              # drop the trailing comment
        r = compare(source, cnl)
        if not r["ok"]:
            flagged += 1
            print(f"FLAG: {source}\n   missing={r['missing']} extra={r['extra']} "
                  f"neg {r['neg_source']}->{r['neg_cnl']}")
    print(f"{len(blocks)} correct pairs checked, {flagged} flagged (false alarms)")
    import cnl_json
    differ = [note for note, cnl in blocks
              if compare(clean0(note), cnl)["ok"] != compare_doc(clean0(note), cnl_json.to_json(cnl))["ok"]]
    print(f"document-based check agrees with the text-based one on {len(blocks) - len(differ)} of {len(blocks)}"
          + (f"; differs on {differ}" if differ else ""))

    # Sensitivity: damage each correct CNL in three ways and count how often the damage is caught.
    def clean(note):
        note = re.sub(r"^[A-F][0-9]+[ab]?\.\s*", "", note)
        return re.sub(r"\s{2,}\(.*\)\s*$", "", note)

    mutations = {
        "negation removed": lambda c: re.sub(r" not ", " ", c, count=1) if " not " in c else None,
        "negation added": lambda c: re.sub(r"^(E1[*?!]*: \S+) (?!not )(?=[a-z])", r"\1 not ", c, count=1)
        if re.search(r"^E1[*?!]*: \S+ (?!not )[a-z]", c) else None,
        "tag dropped": lambda c: re.sub(r" \[(?!mode|time|place|freq|degree|cause)[a-z]+: [A-Za-z][A-Za-z0-9_-]*\]", "", c, count=1)
        if re.search(r" \[(?!mode|time|place|freq|degree|cause)[a-z]+: [A-Za-z][A-Za-z0-9_-]*\]", c) else None,
    }
    for name, mutate in mutations.items():
        tried = caught = 0
        for note, cnl in blocks:
            bad = mutate(cnl)
            if bad is None or bad == cnl or cnl_check.check(bad):
                continue
            if not compare(clean(note), cnl)["ok"]:
                continue
            tried += 1
            caught += not compare(clean(note), bad)["ok"]
        print(f"mutation '{name}': caught {caught} of {tried}")
    return flagged


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--test":
        run_tests()
    elif len(sys.argv) == 3:
        print(compare(sys.argv[1], Path(sys.argv[2]).read_text()))
    else:
        sys.exit(__doc__)
