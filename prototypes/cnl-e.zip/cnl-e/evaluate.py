#!/usr/bin/env python3
"""Score predictions against a hand-checked gold set.

Both files are JSONL with "source" and "cnl"; rows are matched by "source".

Reported, from strict to lenient:
    valid       share of predictions that pass grammar + validator
    exact       share identical to gold after canonical renumbering
    slot F1     precision/recall over slots: who, negation, what, each tag, each flag, line type.
                Event references are compared by the verb they point to, so a different
                but consistent numbering is not punished.
Slot F1 is the number to watch: one wrong attachment costs one slot, not the whole sentence.

Usage:  python3 evaluate.py --gold data/gold.jsonl --pred pred.jsonl [--show 10]
"""
import argparse
import re
from collections import Counter

from lark import Lark, Token, Tree
from lark.exceptions import LarkError

import canon
import cnl_check
from common import HERE, read_jsonl

PARSER = Lark((HERE / "cnl.lark").read_text(), parser="lalr", lexer="contextual",
              propagate_positions=True)


def slots(cnl):
    """Multiset of slots of a (valid) CNL text."""
    text = cnl.strip() + "\n"
    tree = PARSER.parse(text)

    def span(node):
        if isinstance(node, Token):
            return text[node.start_pos:node.end_pos]
        return re.sub(r"\s+", " ", text[node.meta.start_pos:node.meta.end_pos]).strip()

    anchors, seen = {}, Counter()
    for line in tree.children:                      # first pass: a stable name for every event
        body = line.children[1]
        if body.data == "verbal":
            verb = next(c for c in body.children if isinstance(c, Token) and c.type == "WORD")
            name = str(verb)
        else:
            name = body.data
        seen[name] += 1
        anchors[str(line.children[0])] = f"{name}#{seen[name]}"

    def norm(s):
        return re.sub(r"(?<![A-Za-z0-9_'.-])E[0-9]+(?![A-Za-z0-9_'-])",
                      lambda m: "<" + anchors.get(m.group(0), "?") + ">", s)

    out = Counter()
    for line in tree.children:
        me, body = anchors[str(line.children[0])], line.children[1]
        out[("type", me, line.data)] += 1
        if body.data != "verbal":
            out[("body", me, norm(span(body)))] += 1
            continue
        kids, after_verb = body.children, False
        out[("who", me, norm(span(kids[0])))] += 1
        for k in kids[1:]:
            if isinstance(k, Token):
                if k.type == "NOT":
                    out[("not", me)] += 1
                elif k.type == "WORD":
                    after_verb = True
            elif k.data == "complement" and after_verb:
                out[("what", me, norm(span(k)))] += 1
            elif k.data == "tag":
                out[("tag", me, norm(span(k)))] += 1
            elif k.data == "flag":
                out[("flag", me, span(k))] += 1
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", required=True)
    ap.add_argument("--pred", required=True)
    ap.add_argument("--show", type=int, default=0, help="print this many wrong predictions")
    args = ap.parse_args()

    pred = {r["source"]: r["cnl"] for r in read_jsonl(args.pred)}
    gold = read_jsonl(args.gold)
    n = valid = exact = tp = n_pred = n_gold = 0
    wrong = []
    for row in gold:
        n += 1
        g = canon.canonicalize(row["cnl"])
        p = canon.canonicalize(pred.get(row["source"], ""))
        gs = slots(g)
        n_gold += sum(gs.values())
        if not p or cnl_check.check(p):
            wrong.append((row["source"], g, p or "(no prediction)"))
            continue                                  # invalid: all gold slots count as missed
        valid += 1
        exact += p == g
        try:
            ps = slots(p)
        except LarkError:
            ps = Counter()
        n_pred += sum(ps.values())
        tp += sum((gs & ps).values())
        if p != g:
            wrong.append((row["source"], g, p))
    prec = tp / n_pred if n_pred else 0.0
    rec = tp / n_gold if n_gold else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    print(f"texts   {n}")
    print(f"valid   {valid / n:6.1%}")
    print(f"exact   {exact / n:6.1%}")
    print(f"slot    P {prec:.1%}  R {rec:.1%}  F1 {f1:.1%}")
    for src, g, p in wrong[: args.show]:
        print(f"\n# {src}\n--- gold\n{g}\n--- pred\n{p}")


if __name__ == "__main__":
    main()
