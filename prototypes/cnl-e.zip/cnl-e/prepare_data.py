#!/usr/bin/env python3
"""Turn data/examples.txt into data/seed.jsonl  ({"id", "source", "cnl", "kv"} per line;
"cnl" is the bracket form, "kv" the line form of the same content).

The seed set is for few-shot prompting of the teacher and for smoke tests.
It is far too small to train on.

Usage:  python3 prepare_data.py
"""
import re
import cnl_check
import cnl_json
import cnl_kv
from common import HERE, write_jsonl


def main():
    rows, seen = [], set()
    for note, cnl in cnl_check.read_blocks(HERE / "data" / "examples.txt"):
        m = re.match(r"^([A-F][0-9]+[ab]?)\.\s*(.*)$", note)
        ex_id, source = m.group(1), m.group(2)
        source = re.sub(r"\s{2,}\(.*\)\s*$", "", source).strip()
        if source in seen:           # same sentence, second reading (A10b): one input, one target
            continue
        seen.add(source)
        assert not cnl_check.check(cnl), ex_id
        rows.append({"id": ex_id, "source": source, "cnl": cnl,
                     "kv": cnl_kv.dumps(cnl_json.to_json(cnl))})
    write_jsonl(HERE / "data" / "seed.jsonl", rows)
    print(f"wrote data/seed.jsonl: {len(rows)} pairs")


if __name__ == "__main__":
    main()
