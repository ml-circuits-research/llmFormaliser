# Probă: Haiku, doar cu promptul final (`prompts/kv_prompt.txt`), text → scrierea pe linii

- `texts.txt`: 51 de propoziții, niciuna dintre exemplele din prompt.
  - 1–12: referință scrisă înainte de orice rulare cu promptul final (`set: untouched`).
  - 13–24 și 25–36: seturi folosite în rundele anterioare; regulile au fost strânse după ce am
    văzut greșelile de pe ele (`round2`, `round1`).
  - 37–51: fără referință; se măsoară doar validitatea.
- `run1.txt`, `run2.txt`: două rulări independente. `run1_retry.txt`, `run2_retry.txt`: răspunsurile
  corectate după ce modelul a primit mesajele verificatorului pentru cele invalide.
- `gold.jsonl`: cele 36 de referințe.

Modelul a rulat ca subagent și a convertit toate cele 51 de propoziții într-o singură sesiune.

Reproducere:

```
python3 - <<'PY'
import json, re, cnl_kv
texts = [l.strip() for l in open('trials/haiku_lines/texts.txt') if l.strip()]
gold = [json.loads(l) for l in open('trials/haiku_lines/gold.jsonl')]
def load(path):
    out, cur = {}, None
    for l in open(path):
        m = re.match(r"###\s*(\d+)", l)
        if m: cur = int(m.group(1)); out[cur] = []
        elif cur and l.strip(): out[cur].append(l.rstrip("\n"))
    return [{'source': t, 'kv': "\n".join(out.get(i + 1, []))} for i, t in enumerate(texts)]
for run in ('run1', 'run2'):
    rows = load(f'trials/haiku_lines/{run}.txt')
    cnl_kv.evaluate([g for g in gold if g['set'] == 'untouched'], rows)
    cnl_kv.evaluate(gold, rows)
    print('valid:', sum(not cnl_kv.check(r['kv']) for r in rows), 'of', len(rows))
PY
```
