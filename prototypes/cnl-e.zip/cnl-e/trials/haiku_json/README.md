# Probă: Haiku, doar cu prompt, text → JSON

- `texts.txt`: 48 de propoziții. Primele 21 sunt exemple scoase din prompt; următoarele 15 nu au
  referință; ultimele 12 au referință scrisă înainte de a vedea vreun răspuns (`gold_clean.jsonl`).
- `run1.jsonl`, `run2.jsonl`: două rulări independente, același prompt (reguli + 42 de exemple).
- Modelul a rulat ca subagent și a convertit toate cele 48 de propoziții într-o singură sesiune,
  fără validare și fără a doua încercare. Un apel pe propoziție, cu schema impusă de API, ar trebui
  să dea rezultate mai bune la formă; asta nu a fost măsurat.

Reproducere a scorului:

```
python3 - <<'PY'
import json, cnl_json
gold = [json.loads(l) for l in open('trials/haiku_json/gold_clean.jsonl')]
for run in ('run1', 'run2'):
    rows = [json.loads(l) for l in open(f'trials/haiku_json/{run}.jsonl')]
    cnl_json.evaluate(gold, [{'source': r['source'], 'output': json.dumps(r['json'])} for r in rows])
PY
```
