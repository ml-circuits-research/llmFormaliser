#!/usr/bin/env python3
"""Run every check that needs no GPU and no download. About 30 seconds.

Usage:  python3 run_tests.py            (all)
        python3 run_tests.py --core     (grammar + validator only: needs just `lark`)
"""
import subprocess
import sys

CORE = [
    ("grammar + validator on valid and invalid examples", ["cnl_check.py", "--test"]),
    ("seed data", ["prepare_data.py"]),
    ("JSON form: every example converts and passes the JSON checker", ["cnl_json.py", "--test"]),
    ("line form: every example round-trips; broken texts are rejected", ["cnl_kv.py", "--test"]),
]
FULL = [
    ("llguidance grammar agrees with the Lark grammar", ["test_llg.py"]),
    ("lemma check: false alarms and sensitivity", ["lemma_check.py", "--test"]),
    ("evaluation script (gold against itself must be 100%)",
     ["evaluate.py", "--gold", "data/seed.jsonl", "--pred", "data/seed.jsonl"]),
    ("training pipeline on a tiny random model", ["train_lora.py", "--smoke-test"]),
    ("decoding with the grammar mask on a tiny random model", ["infer.py", "--smoke-test"]),
]

failed = []
for title, cmd in CORE + ([] if "--core" in sys.argv else FULL):
    print(f"\n=== {title}")
    r = subprocess.run([sys.executable] + cmd, capture_output=True, text=True)
    lines = [ln for ln in r.stdout.strip().splitlines() if ln.strip()]
    print("\n".join(lines[-4:]))
    if r.returncode != 0:
        failed.append(title)
        print(r.stderr.strip()[-800:])
print("\n" + ("ALL CHECKS PASSED" if not failed else "FAILED: " + "; ".join(failed)))
sys.exit(1 if failed else 0)
