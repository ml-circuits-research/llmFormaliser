#!/usr/bin/env python3
"""Check that cnl_llg.lark (llguidance) accepts/rejects the same texts as cnl.lark (Lark).

Usage: python3 test_llg.py        (needs: pip install llguidance lark)
"""
import sys
from pathlib import Path
import llguidance as llg
from lark.exceptions import LarkError
import cnl_check

HERE = Path(__file__).parent
GRAMMAR = llg.grammar_from("lark", (HERE / "cnl_llg.lark").read_text())
TOK = llg.LLTokenizer("byte")


def llg_accepts(text):
    m = llg.LLMatcher(TOK, GRAMMAR)
    for tok in TOK.tokenize_str(text):
        if not m.consume_token(tok) or m.is_error():
            return False
    return m.is_accepting()


def lark_accepts(text):
    try:
        cnl_check.PARSER.parse(text.strip() + "\n")
        return True
    except LarkError:
        return False


def main():
    err = llg.LLMatcher.validate_grammar(GRAMMAR)
    if err:
        sys.exit("grammar does not compile: " + err)
    ok, n = True, 0
    for fname in ("examples.txt", "invalid.txt"):
        for note, cnl in cnl_check.read_blocks(HERE / "data" / fname):
            n += 1
            a, b = lark_accepts(cnl), llg_accepts(cnl)
            if a != b:
                ok = False
                print(f"MISMATCH lark={a} llguidance={b}: {note}\n{cnl}\n")
    print(f"{n} texts compared | " + ("both grammars agree on all of them" if ok else "DISAGREEMENT"))
    return ok


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
