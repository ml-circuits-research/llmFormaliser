#!/usr/bin/env python3
"""Canonical numbering for CNL-E, so that one meaning has one spelling.

  * events are renumbered E1, E2, ... in line order
  * for each noun lemma, ids are renumbered 1, 2, 3, ... in order of first mention (0 is kept)
  * flags at the end of a line are put in the fixed order PAST FUTURE PERF PROG HABIT POLITE EMPH
  * runs of spaces collapse to one; blank lines and '#' comments are dropped

Text inside "strings" and $formulas$ is never touched.

Usage:  python3 canon.py file.cnl        (prints the canonical text)
"""
import re
import sys

_PROTECTED = re.compile(r'("[^"\n]*"|\$[^$\n]*\$)')
_EVREF = re.compile(r"(?<![A-Za-z0-9_'.-])E([0-9]+)(?![A-Za-z0-9_'-])")
_NOUN = re.compile(r"(?<![A-Za-z0-9_'-])([a-z][a-z0-9_']*)-([0-9]+)(\+?)")


FLAG_ORDER = ["PAST", "FUTURE", "PERF", "PROG", "HABIT", "POLITE", "EMPH"]
_FLAGS = re.compile(r"(?: ?\[(?:" + "|".join(FLAG_ORDER) + r")\])+$")


def _sort_flags(m):
    found = set(re.findall(r"[A-Z]+", m.group(0)))
    return "".join(f" [{f}]" for f in FLAG_ORDER if f in found)


def canonicalize(text):
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln and not ln.startswith("#")]

    events = {}
    for ln in lines:
        m = re.match(r"E([0-9]+)", ln)
        if m and m.group(1) not in events:
            events[m.group(1)] = str(len(events) + 1)
    nouns = {}

    def fix_noun(m):
        lemma, num, plural = m.groups()
        if num == "0":
            return m.group(0)
        ids = nouns.setdefault(lemma, {})
        if num not in ids:
            ids[num] = str(len(ids) + 1)
        return f"{lemma}-{ids[num]}{plural}"

    out = []
    for ln in lines:
        parts = _PROTECTED.split(ln)
        for i in range(0, len(parts), 2):                      # odd parts are strings / formulas
            parts[i] = _EVREF.sub(lambda m: "E" + events.get(m.group(1), m.group(1)), parts[i])
            parts[i] = _NOUN.sub(fix_noun, parts[i])
        out.append(_FLAGS.sub(_sort_flags, "".join(parts)))
    return "\n".join(out)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    print(canonicalize(open(sys.argv[1]).read()))
