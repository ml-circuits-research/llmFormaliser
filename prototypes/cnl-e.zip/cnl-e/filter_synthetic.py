#!/usr/bin/env python3
"""Filter teacher-generated pairs before training.

Each input line is JSON with "source" and "cnl" (and optionally "cnl_b", a second,
independent rendering of the same source by the teacher).

A pair is kept only if, after canonical renumbering:
  1. the CNL passes the grammar and the validator          (cnl_check)
  2. no content word was lost or invented, negations match (lemma_check)
  3. if "cnl_b" is present, both renderings are identical  (self-consistency)
  4. the source was not seen before                        (deduplication)

Usage:
    python3 filter_synthetic.py raw.jsonl --out data/train.jsonl --rejected data/rejected.jsonl
    python3 filter_synthetic.py raw.jsonl --no-lemma        # skip step 2 (no spaCy needed)
"""
import argparse
from collections import Counter
import canon
import cnl_check
from common import read_jsonl, write_jsonl


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("--out", default="data/train.jsonl")
    ap.add_argument("--rejected", default="data/rejected.jsonl")
    ap.add_argument("--no-lemma", action="store_true")
    args = ap.parse_args()

    if not args.no_lemma:
        import lemma_check

    kept, rejected, reasons, seen = [], [], Counter(), set()
    for row in read_jsonl(args.raw):
        source = " ".join(row["source"].split())
        cnl = canon.canonicalize(row.get("cnl") or "")
        why = None
        if not cnl:
            why = "teacher declined"
        elif source.lower() in seen:
            why = "duplicate source"
        elif cnl_check.check(cnl):
            why = "invalid: " + cnl_check.check(cnl)[0]
        elif "cnl_b" in row and canon.canonicalize(row["cnl_b"] or "") != cnl:
            why = "teacher renderings disagree"
        elif not args.no_lemma:
            r = lemma_check.compare(source, cnl)
            if not r["ok"]:
                why = (f"lemma: missing={r['missing']} extra={r['extra']} "
                       f"neg {r['neg_source']}->{r['neg_cnl']}")
        if why:
            reasons[why.split(":")[0]] += 1
            rejected.append({**row, "reason": why})
        else:
            seen.add(source.lower())
            kept.append({"source": source, "cnl": cnl})

    write_jsonl(args.out, kept)
    write_jsonl(args.rejected, rejected)
    total = len(kept) + len(rejected)
    print(f"kept {len(kept)} of {total} -> {args.out}")
    for reason, n in reasons.most_common():
        print(f"  rejected {n:6d}  {reason}")


if __name__ == "__main__":
    main()
