#!/usr/bin/env python3
"""Build the system prompt that makes a fast hosted LLM (Haiku-class) output CNL-E as JSON.

    python3 build_json_prompt.py                 # prompts/json_prompt.txt: rules + all 63 examples
    python3 build_json_prompt.py --holdout DIR   # for testing a model: every third example is kept
                                                 # OUT of the prompt and written to DIR as a test set

Send the prompt as the system message and the text to convert as the user message.
Check every answer with cnl_json.parse_answer() + cnl_json.check(); on errors, send the error
list back and ask for a corrected JSON.
"""
import json
import sys
from pathlib import Path

import cnl_json
from common import HERE, read_jsonl, write_jsonl


def example(pair):
    doc = cnl_json.to_json(pair["cnl"])
    return f"Text: {pair['source']}\n" + json.dumps(doc, ensure_ascii=False, separators=(", ", ": "))


def main():
    pairs = read_jsonl(HERE / "data" / "seed.jsonl")
    rules = (HERE / "prompts" / "json_rules_en.md").read_text(encoding="utf-8")
    holdout = sys.argv[2] if len(sys.argv) == 3 and sys.argv[1] == "--holdout" else None
    shown = [p for i, p in enumerate(pairs) if not (holdout and i % 3 == 2)]
    held = [p for i, p in enumerate(pairs) if holdout and i % 3 == 2]
    prompt = rules + "\n## Examples\n\n" + "\n\n".join(example(p) for p in shown) + "\n"
    if holdout:
        out = Path(holdout)
        out.mkdir(parents=True, exist_ok=True)
        (out / "prompt.txt").write_text(prompt, encoding="utf-8")
        (out / "texts.txt").write_text("\n".join(p["source"] for p in held) + "\n", encoding="utf-8")
        write_jsonl(out / "gold.jsonl", [{"source": p["source"], "json": cnl_json.to_json(p["cnl"])} for p in held])
        print(f"{out}/prompt.txt: {len(shown)} examples | held out for testing: {len(held)}")
    else:
        (HERE / "prompts" / "json_prompt.txt").write_text(prompt, encoding="utf-8")
        print(f"wrote prompts/json_prompt.txt: {len(shown)} examples, {len(prompt)} characters")


if __name__ == "__main__":
    main()
