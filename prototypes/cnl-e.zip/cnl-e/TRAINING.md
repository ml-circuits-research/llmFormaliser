# Indicații de antrenare: text natural → CNL-E

## Recomandarea

**Model:** `Qwen/Qwen3-4B-Instruct-2507`, antrenat cu **LoRA**. Dacă viteza nu ajunge, îl
distilezi apoi într-un student de 0,6–1,7B (`Qwen3-1.7B`, `Qwen3-0.6B`) cu fine-tuning complet.

**Tehnica, într-o frază:** date sintetice de la un model mare, filtrate mecanic → LoRA pe toate
straturile liniare, cu pierderea calculată doar pe răspuns → decodare greedy, validare și, doar
la eșec, decodare constrânsă de gramatică → măsurare cu F1 pe sloturi, pe un set verificat de mână.

**Ce nu am făcut:** nu am antrenat niciun model. Hiperparametrii de mai jos sunt puncte de
plecare rezonabile, nu valori măsurate pe această sarcină. Scripturile au fost rulate cap-coadă
doar pe un model aleator minuscul, pe CPU (`python3 run_tests.py`); nu au rulat pe un model real
sau pe GPU, pentru că mediul în care au fost scrise nu are nici GPU, nici acces la Hugging Face.

### De ce acest model

| Motiv | Detaliu |
| --- | --- |
| Dovadă pe fine-tuning | Într-un benchmark Distil Labs din martie 2026 pe 15 modele mici, Qwen3-4B-Instruct-2507, după fine-tuning, a egalat sau a depășit profesorul de 120B pe 8 din 9 sarcini. |
| Doar text | Fără encoder de imagine sau audio; se încarcă cu `AutoModelForCausalLM`, deci cu orice unealtă obișnuită. |
| Fără „thinking” | Fișa modelului spune că suportă doar modul fără raționament și nu emite blocuri `<think>`; răspunsul începe direct cu CNL-ul. |
| Licență | Apache 2.0. |
| Se potrivește cu ce ai văzut | Ai observat deja că un model de 4B se descurcă mai bine decât Stanza fără antrenare. |

### Alternative

| Model | Când l-aș alege | Ce te costă |
| --- | --- | --- |
| `Qwen/Qwen3.5-4B` (feb. 2026, Apache 2.0) | dacă vrei generația mai nouă și 201 limbi | multimodal (text, imagine, video); „thinking” pornit implicit, trebuie oprit; cere `transformers` foarte recent și altă clasă de model. `train_lora.py` nu îl încarcă fără modificări. |
| Gemma 4 E4B (Apache 2.0) | dacă ținta e un telefon sau laptop | 4,5B parametri efectivi, 8B în total; text, imagine și audio. Aceeași observație despre script. |
| `Qwen3-1.7B`, `Qwen3-0.6B` | ca student, după ce modelul de 4B merge | calitate mai mică la cazurile grele; de măsurat |
| familia LFM2 (350M–2,6B) | dacă vrei cel mai mic model posibil | în același benchmark a fost cea mai „antrenabilă”; verifică licența pentru uz comercial |
| encoder-decoder (T5, ByT5) | nu aș începe de aici | modele mai vechi; avantajul de viteză nu compensează calitatea |

Același benchmark conchide că un model de 1B bine antrenat poate depăși un model de 8B doar
promptat. De aceea merită încercat studentul mic: sarcina ta este îngustă și foarte regulată.

## Ordinea de lucru

1. Închide cele patru decizii din `SPEC.md` (mai ales limba țintă). Orice schimbare ulterioară a
   limbajului invalidează datele.
2. Scrie de mână setul **gold**: 300–500 de perechi, jumătate cazuri grele. Nu intră niciodată în antrenare.
3. Generează 5 000 de perechi sintetice și filtrează-le.
4. Antrenează, evaluează pe gold, citește erorile.
5. Adaugă date țintite pe erorile văzute; repetă 3–5 până când F1 pe sloturi nu mai crește.
6. Abia apoi distilează într-un model mai mic.

## 1. Datele

Aproape toată calitatea vine de aici. Modelul învață limbajul din perechi, nu din prompt.

### Ținte canonice

Un sens trebuie să aibă o singură scriere, altfel modelul învață zgomot. Convențiile sunt:

- evenimentele apar în ordinea în care apar verbele lor în text și sunt numerotate E1, E2, ...;
- id-urile unui substantiv pornesc de la 1 și cresc în ordinea primei apariții;
- etichetele păstrează ordinea din text; marcajele stau ultimele, în ordinea
  `PAST FUTURE PERF PROG HABIT POLITE EMPH`.

`canon.py` repară automat numerotarea și ordinea marcajelor. Ordinea evenimentelor și a
etichetelor față de text nu se poate verifica mecanic; ține de prompt și de setul gold.

### De unde vin propozițiile

- Cel puțin jumătate: text real din domeniul tău. Este singura sursă care seamănă cu ce va vedea modelul.
- Restul: propoziții scrise de profesor pentru fenomene rare. Categoriile și ponderile sugerate
  sunt în `prompts/sentence_generation.md`.
- Cel puțin 10% perechi minimale: aceleași cuvinte, altă structură (scope-ul negației, atașare,
  referentul pronumelui, modal negat). Ele obligă modelul să se uite la structură.
- Amestecă propoziții singure cu paragrafe de 2–5 propoziții; altfel modelul nu învață să țină
  id-urile de la o propoziție la alta.

### De la propoziții la perechi

```
python3 build_teacher_prompt.py          # scrie prompts/teacher_prompt.txt (reguli + 63 de exemple)
# trimite promptul + un lot de propoziții unui model mare, de DOUĂ ori, independent;
# salvează răspunsurile ca {"source", "cnl", "cnl_b"} pe câte o linie în raw.jsonl
python3 filter_synthetic.py raw.jsonl --out data/train.jsonl --rejected data/rejected.jsonl
```

Filtrul păstrează o pereche doar dacă trece toate cele patru verificări:

| Verificare | Ce prinde | Ce nu prinde |
| --- | --- | --- |
| gramatică + validator | formă greșită, referințe rupte, articole, pronume | sens greșit în formă corectă |
| verificarea lemelor | cuvânt de conținut pierdut sau inventat, negație pierdută sau adăugată | complement care e pronume sau referință la eveniment |
| acordul celor două redări | o parte din erorile de atașare și de scope | erorile pe care profesorul le face la fel de două ori |
| deduplicare | aceeași propoziție de două ori | parafraze apropiate |

Pe cele 64 de exemple corecte, verificarea lemelor nu dă nicio alarmă falsă, dar lista ei de
excepții a fost reglată chiar pe aceste exemple; pe text nou va respinge și perechi bune.
La stricări deliberate a prins 11 din 11 negații scoase, 42 din 42 negații adăugate și 7 din 13
etichete șterse. Citește `data/rejected.jsonl`: dacă o regulă e încălcată des, repară promptul
profesorului, nu filtrul.

Profesorul folosit offline nu contrazice scopul tău: la rulare nu există niciun LLM mare.

### Câte perechi

Nu fixa un număr dinainte. Antrenează pe 2 000, 5 000, 10 000 și 20 000 de perechi și oprește-te
când F1 pe sloturi pe gold nu mai crește. Estimarea mea pentru platou este de ordinul zecilor de
mii, dar este o estimare, nu o măsurătoare.

### Setul gold

- 300–500 de perechi verificate de tine, linie cu linie; jumătate cazuri grele și perechi minimale.
- Împarte-l în dev (pentru decizii) și test (privit o singură dată, la final).
- Două persoane care scriu independent același eșantion îți arată cât de bine e definit limbajul:
  unde nu sunteți de acord, regula e neclară și nici modelul nu o va învăța.

## 2. Antrenarea

```
pip install -r requirements.txt
python3 train_lora.py --model Qwen/Qwen3-4B-Instruct-2507 \
    --train data/train.jsonl --eval data/dev.jsonl --out runs/qwen3-4b-cnl --merge
```

| Parametru | Valoare de plecare | De ce |
| --- | --- | --- |
| metodă | LoRA; `--qlora` dacă nu ajunge memoria | 4B încape pe un singur GPU; QLoRA schimbă puțină calitate pe memorie |
| straturi țintă | toate straturile liniare | ieșirea este un limbaj nou, cu sintaxă strictă; doar atenția e de obicei prea puțin |
| rang, alpha, dropout | 32, 64, 0,05 | rang mai mare decât cel uzual de 8–16, din același motiv |
| rată de învățare | 2e-4, cosinus, 5% încălzire | valoarea uzuală pentru LoRA; 2e-5 la `--full` |
| epoci | 3 | urmărește F1 pe dev, nu pierderea |
| lot efectiv | 32 (8 × 4 acumulări) | |
| lungime maximă | 768 de tokeni | perechile mai lungi sunt sărite, nu tăiate: o țintă tăiată este un CNL invalid |
| pierdere | doar pe răspuns | promptul nu trebuie învățat |
| prompt | `Rewrite as CNL-E:` + text | scurt intenționat: fiecare token de prompt se plătește la fiecare apel |

Dacă rămâi fără memorie, scade `--batch` și crește `--grad-accum` în aceeași proporție, sau
adaugă `--qlora`. Pentru student: `--model Qwen/Qwen3-1.7B --full`. Variantele Qwen3 fără
„Instruct-2507” au „thinking” în șablonul de chat și trebuie verificate înainte: rulează
scriptul pe 100 de perechi și uită-te la ce generează `infer.py`.

Promptul trebuie să fie identic la antrenare și la inferență; ambele îl iau din `common.py`.

## 3. Inferența

```
python3 infer.py --model Qwen/Qwen3-4B-Instruct-2507 --check-grammar   # o dată per model
python3 infer.py --model runs/qwen3-4b-cnl/merged --input texte.txt --out pred.jsonl
```

Modul implicit, `fallback`, face trei lucruri: decodare greedy, validare, și doar dacă rezultatul
e invalid, o a doua decodare în care gramatica maschează fiecare token. Un model bine antrenat
ajunge rar la pasul al doilea, deci plătești costul măștii doar unde e nevoie.

| Garanție | Decodare constrânsă | Validator | Verificarea lemelor |
| --- | --- | --- | --- |
| forma fiecărei linii | da | da | |
| referințe și numerotare coerente | | da | |
| niciun cuvânt pierdut sau inventat | | | parțial |
| atașare și scope corecte | | | |

Pentru ultimul rând nu există verificare automată. Dacă un rezultat rămâne invalid sau pică
verificarea lemelor, întoarce un eșec explicit, nu o ghicire.

`--check-grammar` trece cele 63 de CNL-uri de referință prin mască folosind tokenizatorul
modelului real și confirmă că gramatica nu blochează niciun răspuns corect. Eu am putut rula
verificarea doar cu un tokenizator mic, antrenat local.

### Viteză

Nu am măsurători; `infer.py` afișează texte pe secundă și tokeni pe secundă pe mașina ta.
Pârghiile, în ordinea efectului așteptat:

1. un student mai mic (secțiunea 5);
2. LoRA contopit în model (`--merge`), apoi cuantizare și un server cu loturi (llama.cpp, vLLM);
3. loturi de propoziții în paralel în loc de una câte una;
4. promptul scurt, deja aplicat.

Ieșirea are aproximativ lungimea intrării, deci timpul crește liniar cu textul.

`cnl_llg.lark` este gramatica în formatul llguidance. Proiectul llguidance își declară
integrarea în llama.cpp (compilat cu `-DLLAMA_LLGUIDANCE=ON`), SGLang
(`--grammar-backend llguidance`) și vLLM; gramatica se trimite cu prefixul `%llguidance {}`.
Nu am testat aceste servere. Am testat doar că `cnl_llg.lark` acceptă și respinge exact
aceleași 87 de texte ca `cnl.lark`.

## 4. Evaluarea

```
python3 evaluate.py --gold data/dev.jsonl --pred pred.jsonl --show 20
```

| Măsură | Ce spune |
| --- | --- |
| valid | cât de des iese un CNL corect ca formă |
| exact | cât de des iese exact scrierea din gold |
| F1 pe sloturi | cine, negație, ce, fiecare etichetă, fiecare marcaj, tipul liniei; o atașare greșită costă un slot, nu toată propoziția |

Urmărește F1 pe sloturi. Raportează-l separat pe jumătatea grea a setului gold și pe perechile
minimale: acolo se vede dacă modelul a învățat structura sau doar copiază cuvinte. Stabilește
pragul de acceptare înainte de prima antrenare, în funcție de cât costă o eroare în aplicația ta.

După fiecare rulare citește 50 de erori și grupează-le pe tip. Fiecare grup mare devine
200–500 de perechi noi, țintite. Aceasta este bucla care îmbunătățește modelul.

## 5. Distilarea într-un model mai mic

După ce modelul de 4B este suficient de bun pe gold:

1. rulează-l pe 100 000 sau mai multe propoziții reale, neetichetate, din domeniul tău;
2. păstrează doar ieșirile care trec validatorul și verificarea lemelor;
3. antrenează studentul pe datele inițiale plus acestea, cu `--full`;
4. compară cele două modele pe același gold și alege după F1 și viteză.

## 6. Capcane

- **„Thinking” în șablon.** La modelele care îl au, răspunsul începe cu un bloc de raționament
  care strică și ținta, și viteza. Oprește-l sau alege un model fără.
- **Sfârșitul răspunsului.** `train_lora.py` ia sfârșitul de tură din șablonul modelului. Dacă
  modelul antrenat nu se oprește, aici e problema.
- **Aceeași propoziție, două ținte.** O propoziție cu adevărat ambiguă trebuie să aibă o singură
  țintă (cea cu bara verticală între candidați), nu două perechi contradictorii.
- **Exemple negative.** Nu pune CNL greșit în antrenare, nici ca „așa nu”.
- **Limba.** Gramatica acceptă doar litere ASCII; lematizatorul și listele din `lemma_check.py`
  sunt pentru engleză. Româna cere schimbări în toate trei.
- **Schimbarea limbajului.** După orice modificare în `cnl.lark`, modifică la fel `cnl_llg.lark`
  și rulează `python3 run_tests.py`; `test_llg.py` îți spune dacă cele două s-au despărțit.

## Surse

- [What Small Language Model Is Best for Fine-Tuning (Distil Labs, martie 2026)](https://www.distillabs.ai/blog/what-small-language-model-is-best-for-fine-tuning/)
- [Qwen/Qwen3-4B-Instruct-2507, fișa modelului](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507)
- [Qwen/Qwen3.5-4B, fișa modelului](https://huggingface.co/Qwen/Qwen3.5-4B)
- [Gemma 4, fișa modelului](https://ai.google.dev/gemma/docs/core/model_card_4)
- [llguidance: sintaxa gramaticii](https://github.com/guidance-ai/llguidance/blob/main/docs/syntax.md)
- [llguidance: integrări](https://github.com/guidance-ai/llguidance)
- [Unsloth: modele suportate și jurnal de modificări](https://unsloth.ai/docs/new/changelog)
