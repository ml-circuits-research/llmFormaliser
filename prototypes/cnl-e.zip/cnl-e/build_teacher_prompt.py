#!/usr/bin/env python3
"""Assemble prompts/teacher_prompt.txt = rules + every seed pair + the output contract.

Give the result to a large model, followed by a batch of sentences (one per line).
Run it twice per batch, independently, and store the two answers as "cnl" and "cnl_b";
filter_synthetic.py keeps a pair only when both agree and all checks pass.

Usage:  python3 build_teacher_prompt.py
"""
from common import HERE, read_jsonl

HEAD = """You convert text into CNL-E, a controlled language of events. Follow the rules exactly.
Do not explain, do not comment, do not add information that is not in the text.

"""
TAIL = """
## Output format

For each input sentence or short paragraph, output one JSON object per line:
{"source": "<the input, unchanged>", "cnl": "<the CNL-E lines joined with \\n>"}

If a text cannot be expressed without breaking a rule, output {"source": "...", "cnl": null}.
A null is better than a guess: nulls are dropped, wrong pairs poison the training set.

## Texts to convert
"""


def main():
    rules = (HERE / "prompts" / "rules_en.md").read_text(encoding="utf-8")
    pairs = read_jsonl(HERE / "data" / "seed.jsonl")
    examples = ["## Examples\n"]
    for p in pairs:
        examples.append(f"Text: {p['source']}\n{p['cnl']}\n")
    out = HEAD + rules + "\n" + "\n".join(examples) + TAIL
    (HERE / "prompts" / "teacher_prompt.txt").write_text(out, encoding="utf-8")
    print(f"wrote prompts/teacher_prompt.txt: {len(pairs)} examples, {len(out.split())} words")


if __name__ == "__main__":
    main()
