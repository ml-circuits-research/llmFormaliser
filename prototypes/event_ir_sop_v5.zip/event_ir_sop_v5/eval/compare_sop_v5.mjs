import fs from 'node:fs';
import {cases} from './cases_v3.mjs';
import {paragraphs} from './paragraph_cases_v3.mjs';
import {cases as direct} from './direct_compact_v4.mjs';
import {toCompact,fromCompact} from '../src/compact_v4.mjs';
import {toSOPv5,fromSOPv5,validateSOPv5} from '../src/sop_v5.mjs';
import {toCNLv4} from '../src/cnl_v4.mjs';
import {signatureF1} from '../src/signature.mjs';
import {validateIR} from '../src/validate_v3.mjs';

const base=[...cases.map(c=>({name:c.name,text:c.text,ir:c.ir,group:'sentence'})),...paragraphs.flatMap(p=>p.sentences.map((ir,i)=>({name:`${p.name}#${i+1}`,text:ir.text,ir,group:'paragraph-sentence'})))];
const held=direct.map(c=>({name:`direct:${c.name}`,text:c.text,ir:fromCompact(c.compact,{sourceText:c.text}),group:'direct',score:c.score}));
const all=[...base,...held];
const minjson={chars:0,subwords:0},v4={chars:0,subwords:0},v5={chars:0,subwords:0};
const subwordProxy=s=>(String(s).replace(/_/g,' ').match(/"(?:\\.|[^"\\])*"|\$?@?[A-Za-z]+|\d+|[^\s]/g)||[]).length;
const add=(o,s)=>{o.chars+=s.length;o.subwords+=subwordProxy(s);};
let sig=0,cnl=0,valid=0,sop=0,noSnake=0;const failures=[];
for(const c of all){
  const j=JSON.stringify(c.ir),c4=toCompact(c.ir),c5=toSOPv5(c.ir);
  add(minjson,j);add(v4,c4);add(v5,c5);
  const ve=validateSOPv5(c5);if(!ve.length)sop++;else failures.push({name:c.name,kind:'SOP',errors:ve});
  if(!c5.includes('_'))noSnake++;else failures.push({name:c.name,kind:'underscore',sop:c5});
  const back=fromSOPv5(c5,{sourceText:c.text});
  if(signatureF1(c.ir,back).f1===1)sig++;else failures.push({name:c.name,kind:'signature',f1:signatureF1(c.ir,back).f1});
  if(toCNLv4(c.ir)===toCNLv4(back))cnl++;else failures.push({name:c.name,kind:'cnl'});
  if(validateIR(back).length===0)valid++;else failures.push({name:c.name,kind:'ir',errors:validateIR(back)});
}
const pct=(a,b)=>100*a/b;
const scoreSent=cases.reduce((a,c)=>a+c.judge.score,0)/cases.length;
const scorePara=paragraphs.reduce((a,p)=>a+p.judge.score,0)/paragraphs.length;
const scoreDirect=direct.reduce((a,c)=>a+c.score,0)/direct.length;
const result={
  n:all.length,
  groups:{sentence:cases.length,paragraph_sentence:base.length-cases.length,direct:held.length},
  roundtrip:{semantic_signature_exact:sig,cnl_exact:cnl,ir_valid:valid,sop_valid:sop,no_snake_case_values:noSnake},
  semantic_self_eval:{sentence_mean:scoreSent,paragraph_mean:scorePara,direct_mean:scoreDirect},
  length:{
    minified_json:{...minjson,char_vs_json:100,subword_vs_json:100},
    compact_v4:{...v4,char_vs_json:pct(v4.chars,minjson.chars),subword_vs_json:pct(v4.subwords,minjson.subwords)},
    sop_v5:{...v5,char_vs_json:pct(v5.chars,minjson.chars),subword_vs_json:pct(v5.subwords,minjson.subwords),char_vs_v4:pct(v5.chars,v4.chars),subword_vs_v4:pct(v5.subwords,v4.subwords)}
  },
  prompt_chars:{v4:7776,v5:fs.readFileSync('PROMPT_V5_SOP.md','utf8').length},
  failures
};
console.log(JSON.stringify(result,null,2));
console.log('\nEXAMPLES\n');
for(const n of ['must-not','not-required','focus-only','definite-presupposition','not-every']){const c=cases.find(x=>x.name===n);console.log(`--- ${n} ---\n${toSOPv5(c.ir)}\n`);}
