import {cases} from './cases_v3.mjs';
import {formalizeSOP} from '../src/llm_formalizer_sop.mjs';
import {validateIR} from '../src/validate_v3.mjs';
import {signatureF1} from '../src/signature.mjs';
import {validateSOPv5} from '../src/sop_v5.mjs';

const limit=Math.max(1,Math.min(cases.length,Number(process.env.EVAL_LIMIT||cases.length)));
const rows=[];
for(let i=0;i<limit;i++){
  const c=cases[i];
  try{
    const {sop,ir}=await formalizeSOP(c.text);
    const syntaxErrors=validateSOPv5(sop),irErrors=validateIR(ir),sim=signatureF1(c.ir,ir);
    rows.push({name:c.name,syntax:syntaxErrors.length===0,valid:irErrors.length===0,f1:sim.f1,precision:sim.precision,recall:sim.recall,chars:sop.length,syntaxErrors,irErrors});
    console.log(`${i+1}/${limit}\t${c.name}\tsop=${syntaxErrors.length===0}\tir=${irErrors.length===0}\tf1=${sim.f1.toFixed(3)}\tchars=${sop.length}`);
  }catch(e){rows.push({name:c.name,syntax:false,valid:false,f1:0,precision:0,recall:0,chars:0,error:e.message});console.log(`${i+1}/${limit}\t${c.name}\tERROR\t${e.message}`);}
}
const mean=k=>rows.reduce((a,r)=>a+(r[k]||0),0)/rows.length;
console.log('\nSOP MODEL EVAL');
console.log(`model=${process.env.LLM_MODEL||'(unset)'}`);
console.log(`n=${rows.length}`);
console.log(`sop_valid_rate=${(rows.filter(r=>r.syntax).length/rows.length).toFixed(4)}`);
console.log(`ir_valid_rate=${(rows.filter(r=>r.valid).length/rows.length).toFixed(4)}`);
console.log(`signature_precision=${mean('precision').toFixed(4)}`);
console.log(`signature_recall=${mean('recall').toFixed(4)}`);
console.log(`signature_f1=${mean('f1').toFixed(4)}`);
console.log(`mean_output_chars=${mean('chars').toFixed(1)}`);
