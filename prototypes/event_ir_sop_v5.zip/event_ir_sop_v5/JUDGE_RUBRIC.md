# Semantic Round-Trip Judge Rubric

This project uses two distinct evaluations and they must not be confused.

## A. Representation-capacity score

Question: assuming a competent formalizer produced the supplied Event IR, how faithfully can the deterministic CNL expose the source meaning?

100 = no material semantic loss identified.
99 = essentially complete, but one residual issue is intrinsically contextual/theory-dependent rather than silently lost.
95-98 = core meaning preserved with a noticeable nuance underspecified.
90-94 = usable but an important semantic relation or pragmatic distinction is only approximated.
<90 = important meaning lost or incorrectly asserted.

Check independently:

- propositional content
- participant roles
- negation scope
- modal type/scope
- tense/aspect/time
- quantification/cardinality/scope
- conditions and alternatives
- source/commitment status
- presupposition/factivity
- focus and conventional meaning
- coreference/attachment uncertainty
- discourse dependencies

A score must not increase merely because the JSON is structurally valid.

## B. Formalizer-model score

Question: can an actual model infer the target IR from unseen NL?

Use `eval/eval_model.mjs`. It reports:

- JSON/validation success
- unmapped rate
- automatic semantic-signature precision/recall/F1 against frozen gold IR

For publishable evidence, also use a blinded human or independent high-capability semantic judge on a held-out set.

## Why the current 99+ result is not model accuracy

The v3 gold IR was authored/iterated by the same reasoning process that designed the schema. Therefore the 99+ semantic round-trip number demonstrates representation adequacy on this benchmark, not that a 0.6B/1B/4B model can infer the representation at 99+ accuracy.
