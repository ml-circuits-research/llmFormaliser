# SOP v5 experiment results

## Goal

Replace verbose JSON and opaque phrase-like enum values with a compact SOP-style semantic graph:

```text
@id TYPE key=value ...
```

with `$id` references and compositional primitive fields.

## Corpus

- 64 sentence benchmark cases
- 16 sentence units extracted from messy paragraph cases
- 13 held-out/direct formalizations
- total: **93 formalizations**

## Structural / semantic round-trip

| Test | Result |
|---|---:|
| SOP syntax valid | 93 / 93 |
| every `$ref` resolves | 93 / 93 |
| no snake_case semantic value | 93 / 93 |
| legacy IR structurally valid after round-trip | 93 / 93 |
| semantic signature exact | 93 / 93 |
| generated CNL exactly identical | 93 / 93 |

Thus the V5 cleanup caused **zero detected semantic loss** on the complete test set.

## Size

Across all 93 formalizations:

| Format | Characters | Relative to minified JSON |
|---|---:|---:|
| Minified JSON | 103,031 | 100.00% |
| Compact V4 | 22,700 | 22.03% |
| **SOP V5** | **21,175** | **20.55%** |

SOP V5 is:

- **79.45% smaller than minified JSON** by characters;
- **6.72% smaller than Compact V4** by characters.

A tokenizer-independent subword proxy that splits normal lexical/punctuation boundaries and also splits snake_case gives:

| Format | Proxy pieces | Relative to JSON |
|---|---:|---:|
| Minified JSON | 26,748 | 100.00% |
| Compact V4 | 9,043 | 33.81% |
| **SOP V5** | **8,492** | **31.75%** |

On this proxy, SOP V5 is **6.09% smaller than V4** and **68.25% smaller than JSON**.

This is not a real Qwen/Llama tokenizer measurement; use `eval_model_sop.mjs` with the target model for final latency/token measurements.

## Prompt size

- V4 compact prompt: 7,776 characters
- V5 SOP prompt: 5,017 characters
- reduction: **35.48%**

## Inherited semantic self-evaluation

Because V5 round-trips to exactly the same semantic IR and CNL, the previous semantic self-evaluation is unchanged:

- sentence benchmark mean: **99.890625 / 100**
- paragraph benchmark mean: **99.555556 / 100**
- 13 held-out/direct cases: **99.692308 / 100**

These scores remain self-evaluation, not independent proof of small-model NL→SOP accuracy.

## Important cleanup examples

Old opaque value:

```text
ps1 PS t=definite_description_existence_uniqueness ent=$x1
```

V5:

```text
@ps1 PS exists=$x1 unique=$x1 cause=def
```

Old:

```text
l1 L t=unless f=$e1 to=$e2 sem=exception_condition
```

V5:

```text
@l1 L t=unless f=$e1 to=$e2
```

Old:

```text
op1 OP t=focus v=scalar_even dom=contextual_scale ...
```

V5:

```text
@o1 OP t=focus v=scalar cue=even dom=context scale=rank ...
```

The latter representations expose semantics as separately inspectable primitives rather than memorized labels.
