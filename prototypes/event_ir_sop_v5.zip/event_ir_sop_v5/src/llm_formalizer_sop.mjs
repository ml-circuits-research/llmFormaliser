import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {fromSOPv5,validateSOPv5} from './sop_v5.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
function stripFence(s){const t=String(s??'').trim();const m=t.match(/^```(?:text|sop)?\s*([\s\S]*?)\s*```$/i);return m?m[1].trim():t;}
export async function loadSOPPrompt(promptPath=path.join(root,'PROMPT_V5_SOP.md')){return fs.readFile(promptPath,'utf8');}
export async function formalizeSOP(text,opts={}){
  const baseURL=(opts.baseURL||process.env.LLM_BASE_URL||'http://127.0.0.1:8000/v1').replace(/\/$/,'');
  const apiKey=opts.apiKey??process.env.LLM_API_KEY??'dummy';
  const model=opts.model||process.env.LLM_MODEL;if(!model)throw new Error('Missing model. Set LLM_MODEL.');
  const prompt=opts.prompt||await loadSOPPrompt(opts.promptPath);
  const body={model,temperature:opts.temperature??0,messages:[{role:'system',content:prompt},{role:'user',content:`Formalize this source text:\n\n${text}`} ]};
  const r=await fetch(`${baseURL}/chat/completions`,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${apiKey}`},body:JSON.stringify(body),signal:opts.signal});
  if(!r.ok)throw new Error(`LLM HTTP ${r.status}: ${await r.text()}`);const data=await r.json();
  const sop=stripFence(data?.choices?.[0]?.message?.content);if(!sop)throw new Error('Empty LLM output');
  const errors=validateSOPv5(sop);if(errors.length)throw new Error(`Invalid SOP v5: ${errors.join('; ')}`);
  return {sop,ir:fromSOPv5(sop,{sourceText:text})};
}
