# Event IR SOP v5

A compact event-centric semantic formalization experiment for:

```text
Natural language -> SOP-style Event IR -> deterministic CNL -> semantic validation
```

## Current recommendation

Use **SOP v5** as the LLM output format.

```text
@s1 S
@x1 E h=person ty=person n=John
@e1 EV p=leave ag=$x1 root=$o2
@o1 OP t=negation sc=$e1
@o2 OP t=deontic v=required sc=$o1
```

Every output is declared with `@`; every reference uses `$`.

Long semantic phrases are not allowed as enum values. Meaning is decomposed into atomic fields.

For example:

```text
@ps1 PS exists=$x1 unique=$x1 cause=def
```

instead of a value such as `definite_description_existence_uniqueness`.

## Main files

- `PROMPT_V5_SOP.md` — prompt for an LLM formalizer
- `SOP_V5_SPEC.md` — syntax and semantic conventions
- `src/sop_v5.mjs` — serializer, parser adapter, and SOP validator
- `src/llm_formalizer_sop.mjs` — OpenAI-compatible LLM client
- `bin/formalize_sop.mjs` — CLI
- `examples/corpus_v5_sop.json` — benchmark examples
- `examples/direct_sop_v5.json` — held-out/direct examples
- `eval/compare_sop_v5.mjs` — JSON/V4/V5 comparison
- `tests/v5_sop.test.mjs` — regression tests
- `RESULTS_SOP_V5.md` — measured results

## Run

```bash
npm test
npm run eval:sop
```

To use a local OpenAI-compatible endpoint:

```bash
export LLM_BASE_URL=http://127.0.0.1:8000/v1
export LLM_MODEL=your-model

echo 'John must not leave.' | node bin/formalize_sop.mjs
```

## Current evidence

On 93 stored formalizations:

- semantic signature round-trip: 93/93
- CNL exact round-trip: 93/93
- SOP validation: 93/93
- hidden snake_case semantic values: 0
- V5 character size: 20.55% of minified JSON

This proves that the tested semantic structures can be represented losslessly in the compact V5 syntax. It does **not** yet prove that a small LLM can generate them at the same accuracy from arbitrary natural language. That is the next benchmark.
